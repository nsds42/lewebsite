<?php
/** A simple rich textarea block **/
class AQ_Editor_Block extends AQ_Block {
	
	//set and create block
	function __construct() {
		$block_options = array(
			'name' => __('Visual Editor', 'aqpb-l10n'),
			'size' => 'span6',
		);
		
		//create the block
		parent::__construct('aq_editor_block', $block_options);
	}
	
	function form($instance) {
		
		$defaults = array(
			'title' => '',
			'text' => '',
			'effect' => 'left_effect',	
			'layout' => 'full_layout'
		);
		$instance = wp_parse_args($instance, $defaults);
		extract($instance);
		$layout_options = array(
			'full_layout' => '1/1 Column',
			'half_layout' => '1/2 Column',
			'one_third' => '1/3 Column',
			'two_third' => '2/3 Column',
			'one_fourth' => '1/4 Column',
			'three_fourth' => '3/4 Column',
		);    
		$effect_options = array(
			'left_effect' => 'fadeInLeft',
			'right_effect' => 'fadeInRight',
			'up_effect' => 'fadeInUp',					
		); 	
		?>
		<p class="description">
			<label for="<?php echo $this->get_field_id('title') ?>">
				Title (optional)
				<?php echo aq_field_input('title', $block_id, $title, $size = 'full') ?>
			</label>
		</p>
		
		<p class="description">
			<label for="<?php echo $this->get_field_id('text') ?>">
				Content
				<?php 
				$args = array (
				    'tinymce'       => true,
				    'quicktags'     => true,
				    'textarea_name' => $this->get_field_name('text')
				);
				wp_editor( htmlspecialchars_decode($text), $this->get_field_id('text'), $args );
				?>
			</label>
		</p>
		<div class="cf"></div>
		<div class="description half">
			<label for="<?php echo $this->get_field_id('layout') ?>">
				Chosen Layout<br/><em style="font-size: 0.8em;">(Default: Full width)</em><br/>
				<?php echo aq_field_select('layout', $block_id, $layout_options, $layout, $size = 'full') ?>
			</label>
		</div>
		<div class="description half last">
			<label for="<?php echo $this->get_field_id('effect') ?>">
				Chosen Effect<br/><em style="font-size: 0.8em;">(Default: fadeInLeft)</em><br/>
				<?php echo aq_field_select('effect', $block_id, $effect_options, $effect, $size = 'full') ?>
			</label>
		</div>
		<div class="cf"></div>
		<?php
	}
	
	function block($instance) {
		extract($instance);
		$effect_fade = '';
		$columns_layout = '';
		switch($effect) {
				case 'right_effect':
					$effect_fade = 'data-appear-top-offset="-100" data-animated="fadeInRight"';
					break;
				case 'up_effect':
					$effect_fade = 'data-appear-top-offset="-100" data-animated="fadeInUp"';
					break;				
				default:
					$effect_fade = 'data-appear-top-offset="-100" data-animated="fadeInLeft"';	
			}
		switch($layout) {
				case 'half_layout':
					$columns_layout = 'eight columns';
					break;
				case 'one_third':
					$columns_layout = 'one-third column';
					break;
				case 'two_third':
					$columns_layout = 'two-thirds column';				
					break;
				case 'three_fourth':
					$columns_layout = 'twelve columns';
					break;
				case 'one_fourth':
					$columns_layout = 'four columns';
					break;	
				default:
					$columns_layout = 'sixteen columns';	
			}
			echo '<div class="'.$columns_layout.'"'.$effect_fade.'>';
			//if($title) echo '<h4 class="aq-block-title">'.strip_tags($title).'</h4>';
			echo wpautop(do_shortcode(htmlspecialchars_decode($text)));
			echo '</div>';
	}
	
}