<?php
/** Contact Form Block **/

class ST_Contact_Block extends AQ_Block {

    //set and create block
    function __construct() {
        $block_options = array(
            'name' => '<i class="fa fa-envelope"></i> Contact Form',
            'size' => 'col-md-12',
        );

        //create the block
        parent::__construct('st_contact_block', $block_options);
    }

    function form($instance) { 
    	
		$args = array (
			'nopaging' => true,
			'post_type' => 'wpcf7_contact_form',
			'status' => 'publish',
		);
		$contacts = get_posts($args);
		
    	$contact_options = array(); $default_contact = '';
		foreach ($contacts as $contact) {
			$default_contact = empty($default_contact) ? $contact->ID : $default_contact;
			$contact_options[$contact->ID] = htmlspecialchars($contact->post_title);
		}
				
        $defaults = array(
        	'contact' => $default_contact,
			'title' => '',          
            'content' => '',
			'title_info' => '',
			'title_social' => '',
			'content_social' => ''
            
        ); 
        $instance = wp_parse_args($instance, $defaults);
        extract( $instance);

        ?>
        <h3 style="text-align: center;">Contact Form Left</h3>
		<div class="description">
			<label for="<?php echo $block_id ?>_title">
				Title (optional)<br/><em style="font-size: 0.8em;">(Please enter title)</em><br/>
				<?php echo aq_field_input('title', $block_id, $title, $size = 'full') ?>
			</label>
		</div>
		<div class="description">
			<label for="<?php echo $block_id ?>_contact">
				Choose contact form<br/><em style="font-size: 0.8em;">(Chosen contact form)</em><br/>
				<?php echo aq_field_select('contact', $block_id, $contact_options, $contact); ?>
			</label>
		</div>		
        <h3 style="text-align: center;">Contact Info Right</h3>
		<div class="description">
			<label for="<?php echo $block_id ?>_title_info">
				Title Info (optional)<br/><em style="font-size: 0.8em;">(Please enter title info)</em><br/>
				<?php echo aq_field_input('title_info', $block_id, $title_info, $size = 'full') ?>
			</label>
		</div>
		<div class="description">
			<label for="<?php echo $block_id ?>_content">
				Content info (optional)<br/><em style="font-size: 0.8em;">(Please enter content info)</em><br/>
				<?php echo aq_field_textarea('content', $block_id, $content, $size = 'full') ?>
			</label>
		</div>
		<h3 style="text-align: center;">Contact Social Right</h3>
		<div class="description">
			<label for="<?php echo $block_id ?>_title_social">
				Title Social (optional)<br/><em style="font-size: 0.8em;">(Please enter title social)</em><br/>
				<?php echo aq_field_input('title_social', $block_id, $title_social, $size = 'full') ?>
			</label>
		</div>
		<div class="description">
			<label for="<?php echo $block_id ?>_content_social">
				Content social (optional)<br/><em style="font-size: 0.8em;">(Please enter content social)</em><br/>
				<?php echo aq_field_textarea('content_social', $block_id, $content_social, $size = 'full') ?>
			</label>
		</div>
	<?php
    }

    function block($instance) {
        extract($instance);      
    ?>
<div class="container">

<div class="twelve alt columns">

	<h3 class="headline"><?php echo htmlspecialchars_decode($title); ?></h3><span class="line" style="margin-bottom: 35px;"></span><div class="clearfix"></div>
	
	<!-- Contact Form -->
	<section id="contact" data-appear-top-offset="-100" data-animated="fadeInLeft">
		<?php 
			//echo do_shortcode(htmlspecialchars_decode($title));	
			echo do_shortcode('[contact-form-7 id="'.$contact.'" title="contact form 2"]');
		?>
	</section>
	<!-- Contact Form / End -->
</div>
<!-- Container / End -->


<!-- Sidebar
================================================== -->
<div class="four columns" data-appear-top-offset="-100" data-animated="fadeInRight">

	<!-- Information -->
	<div class="widget" style="margin-top:0;">
		<h3 class="headline"><?php echo htmlspecialchars_decode($title_info); ?></h3><span class="line"></span><div class="clearfix"></div>
		<?php echo htmlspecialchars_decode($content); ?>
	</div>
	
	<!-- Social -->
	<div class="widget">
		<h3 class="headline"><?php echo htmlspecialchars_decode($title_social); ?></h3><span class="line" style="margin-bottom: 25px;"></span><div class="clearfix"></div>
		<?php echo htmlspecialchars_decode($content_social); ?>
		<div class="clearfix"></div>
	</div>
</div>
</div>

    <?php  
    }
}