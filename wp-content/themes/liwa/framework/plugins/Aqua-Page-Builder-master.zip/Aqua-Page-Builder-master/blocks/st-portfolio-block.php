<?php
/* Work Block */
if(!class_exists('ST_Portfolio_Block')) {
class ST_Portfolio_Block extends AQ_Block {
   
   function __construct() {
	    $block_options = array(
	    'name' => '<i class="fa fa-archive"></i> Portfolio',
	    'size' => 'col-md-12',
    );
    
	    //create the widget
	    parent::__construct('st_portfolio_block', $block_options);
    } 
    
   function form($instance){
        $defaults = array(
			'title' => 'Title Portfolio',
		    'show' => '4',
			'orderby' => 'title',
			'orderpost' => 'ASC'
        );
        $instance = wp_parse_args($instance, $defaults);
        extract($instance);
		$orderpost_options = array (
			'ASC' => 'ASC : lowest to highest',
			'DESC' => 'DESC : highest to lowest',	
		);
		
		$orderby_options = array (
			'title' => 'Title',
			'date' => 'Date',
			'rand' => 'Random'
		);
        ?>
        <h3 style="text-align: center;">Portfolio</h3>
		<div class="description">
	        <label for="<?php echo $this->get_field_id('title') ?>">
	        Title<br/><em style="font-size: 0.8em;">(Please enter title portfolio)</em><br/>
	        <?php echo aq_field_input('title', $block_id, $title, $size = 'full') ?>
	        </label>
	    </div>
		<div class="cf"></div>
    	<div class="description third">
    		<label for="<?php echo $this->get_field_id('show') ?>">
    			Show portfolio<br/><em style="font-size: 0.8em;">(Chosen number portfolio. Ex: 6)</em><br/>
    			<?php echo aq_field_input('show', $block_id, $show, $size = 'full',$type = 'number') ?>
    		</label>
    	</div>
		<div class="description third">
    		<label for="<?php echo $this->get_field_id('orderpost') ?>">
    			Sort Order<br/><em style="font-size: 0.8em;">Sort from lowest to highest (Default)</em><br/>
    			<?php echo aq_field_select('orderpost', $block_id, $orderpost_options, $orderpost, $size = 'full') ?>
    		</label>
    	</div>
		<div class="description third last">
    		<label for="<?php echo $this->get_field_id('orderby') ?>">
    			Order by<br/><em style="font-size: 0.8em;">Title (Default)</em><br/>
    			<?php echo aq_field_select('orderby', $block_id, $orderby_options, $orderby, $size = 'full') ?>
    		</label>
    	</div>
		
		<div class="cf"></div>
        <?php
        } 
   function block($instance){
    extract($instance);
		$title1 = (!empty($title) ? ' '.esc_attr($title) : '');  
		$desc1 = (!empty($subtitle) ? ' '.esc_attr($subtitle) : '');  
		$show1 = (!empty($show) ? ' '.esc_attr($show) : '');
		$text1 = (!empty($text) ? ' '.esc_attr($text) : '');
	?>
	
	<!-- Container -->
<div class="container">

	<!-- Headline -->
<div class="fiveteen columns">
    <div class="container">
		<h3 class="headline"><?php echo htmlspecialchars_decode($title1); ?></h3>
		<span class="line" style="margin-bottom:35px;"></span>
	  </div>
			<ul class="grid cs-style">
			<?php 
						$args = array(   
							'post_type' => 'portfolio',   
							'posts_per_page' => $show1,
							'order' => $orderpost,
							'orderby' => $orderby, 
						);  
						$wp_query = new WP_Query($args);
						$i = 1;
						while ($wp_query -> have_posts()) : $wp_query -> the_post(); 
						$cates = get_the_terms(get_the_ID(),'categories');
						$cate_name ='';
						$cate_slug = '';
							  foreach((array)$cates as $cate){
								if(count($cates)>0){
									$cate_name .= $cate->name.' ' ;
									$cate_slug .= $cate->slug .' ';     
								} 
						} 
					?>	
					<li>
						<figure>
							<?php $params = array( 'width' => 573, 'height' => 394 );
								  $image = bfi_thumb( wp_get_attachment_url(get_post_thumbnail_id()), $params ); ?>
							<img src="<?php echo $image; ?>" alt="<?php the_title(); ?>"/>
							<figcaption>
								<h3><?php the_title();?></h3>
								<span><?php echo $cate_name;?></span>
								<a href="<?php the_permalink(); ?>"><?php global $theme_option; echo $theme_option['portfolio_read']; ?></a>
							</figcaption>
						</figure>
					</li>
				<?php $i++;
					endwhile;?>
			</ul>
			<div class="clearfix"></div>
     </div>
</div>
<!-- Container / End -->

    <?php
    }
    function update($new_instance, $old_instance) {
	    $new_instance = aq_recursive_sanitize($new_instance);
	    return $new_instance;
	}      
}
}