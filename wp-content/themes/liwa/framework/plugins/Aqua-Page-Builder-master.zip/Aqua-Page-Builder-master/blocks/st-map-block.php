<?php
/* List Block */
if(!class_exists('ST_Maps_Block')) {
class ST_Maps_Block extends AQ_Block {

	function __construct() {
		$block_options = array(
		'name' => '<i class="fa fa-map-marker"></i> GMaps',
		'size' => 'col-md-6',
	);

	//create the widget
	parent::__construct('st_maps_block', $block_options);
	
	//add ajax functions
	
	}
   function form($instance){
        $defaults = array(
            'title' => '',
			'address' => 'Yogyakarta',
        );
        $instance = wp_parse_args($instance, $defaults);
        extract($instance);  	
    ?>    
   	<div class="description">
		<label for="<?php echo $this->get_field_id('title') ?>">
			Title <br/><em style="font-size: 0.8em;">(Please enter title)</em><br/>
			<?php echo aq_field_input('title', $block_id, $title, $size = 'full') ?>
		</label>
	</div>
	<h3 style="text-align: center;">Settings Google Map</h3><br />
	<div class="description">
		<label for="<?php echo $block_id ?>_address">
			Address (optional)<br/>
			<?php echo aq_field_input('address', $block_id, $address, $size = 'full') ?>
		</label>
	</div>
      <?php   
        }
   function block($instance){
   extract($instance);        
	$title = (!empty($title) ? ' '.esc_attr($title) : ''); 
	$desc = (!empty($desc) ? ' '.esc_attr($desc) : '');  
    ?>

<!-- Container -->
<div class="container">
	<div class="sixteen columns">
		<h3 class="headline"><?php echo htmlspecialchars_decode($title); ?></h3><span class="line" style="margin-bottom: 35px;"></span><div class="clearfix"></div>
	</div>
</div>
<!-- Container / End -->


<!-- Container -->
<div class="container">
	<div class="sixteen columns" data-appear-top-offset="-100" data-animated="fadeInUp">

		<!-- Google Maps -->
		<section class="google-map-container">

			<div id="googlemaps" class="google-map google-map-full"></div>
			<script type="text/javascript">
				jQuery('#googlemaps').gMap({
					maptype: 'ROADMAP',
					scrollwheel: false,
					zoom: 14,
					markers: [
						{
							address: '<?php echo $address; ?>', // Your Adress Here
							html: '',
							popup: false,
						}
					],
				});
			</script>

		</section>
		<!-- Google Maps / End -->

	</div>
</div>
<!-- Container / End -->

	<?php 
}
function update($new_instance, $old_instance) {
		$new_instance = aq_recursive_sanitize($new_instance);
		return $new_instance;
	}
}
}