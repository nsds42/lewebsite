<?php
/** A simple text block **/
class AQ_Text_Block extends AQ_Block {
	
	//set and create block
	function __construct() {
		$block_options = array(
			'name' => __('Text', 'aqpb-l10n'),
			'size' => 'span6',
		);
		
		//create the block
		parent::__construct('aq_text_block', $block_options);
	}
	
	function form($instance) {
		
		$defaults = array(
			'title' => '',
			'text'   => '',
			'filter' => 0,
			'effect' => 'left_effect',	
			'layout' => 'full_layout'
		);
		$instance = wp_parse_args($instance, $defaults);
		extract($instance);
		$layout_options = array(
			'full_layout' => '1/1 Column',
			'half_layout' => '1/2 Column',
			'one_third' => '1/3 Column',
			'two_third' => '2/3 Column',
			'one_fourth' => '1/4 Column',
			'three_fourth' => '3/4 Column',
		);    
		$effect_options = array(
			'left_effect' => 'fadeInLeft',
			'right_effect' => 'fadeInRight',
			'up_effect' => 'fadeInUp',					
		); 	
		?>
		<p class="description">
			<label for="<?php echo $this->get_field_id('title') ?>">
				Title (optional)
				<?php echo aq_field_input('title', $block_id, $title, $size = 'full') ?>
			</label>
		</p>
		
		<p class="description">
			<label for="<?php echo $this->get_field_id('text') ?>">
				Content
				<?php echo aq_field_textarea('text', $block_id, $text, $size = 'full') ?>
			</label>
			<label for="<?php echo $this->get_field_id('filter') ?>">
				<?php echo aq_field_checkbox('filter', $block_id, $filter) ?>
				<?php _e('Automatically add paragraphs', 'aqpb-l10n') ?>
			</label>
		</p>
		<div class="cf"></div>
		<div class="description half">
			<label for="<?php echo $this->get_field_id('layout') ?>">
				Chosen Layout<br/><em style="font-size: 0.8em;">(Default: Full width)</em><br/>
				<?php echo aq_field_select('layout', $block_id, $layout_options, $layout, $size = 'full') ?>
			</label>
		</div>
		<div class="description half last">
			<label for="<?php echo $this->get_field_id('effect') ?>">
				Chosen Effect<br/><em style="font-size: 0.8em;">(Default: fadeInLeft)</em><br/>
				<?php echo aq_field_select('effect', $block_id, $effect_options, $effect, $size = 'full') ?>
			</label>
		</div>
		<div class="cf"></div>
		<?php
	}
	
	function block($instance) {
		extract($instance);
		
		$wp_autop = ( isset($wp_autop) ) ? $wp_autop : 0;
		$effect_fade = '';
		$columns_layout = '';
		switch($effect) {
				case 'right_effect':
					$effect_fade = 'data-appear-top-offset="-100" data-animated="fadeInRight"';
					break;
				case 'up_effect':
					$effect_fade = 'data-appear-top-offset="-100" data-animated="fadeInUp"';
					break;				
				default:
					$effect_fade = 'data-appear-top-offset="-100" data-animated="fadeInLeft"';	
			}
		switch($layout) {
				case 'half_layout':
					$columns_layout = 'eight columns';
					break;
				case 'one_third':
					$columns_layout = 'one-third column';
					break;
				case 'two_third':
					$columns_layout = 'two-thirds column';				
					break;
				case 'three_fourth':
					$columns_layout = 'twelve columns';
					break;
				case 'one_fourth':
					$columns_layout = 'four columns';
					break;	
				default:
					$columns_layout = 'sixteen columns';	
			}
			
		echo '<div class="'.$columns_layout.'"'.$effect_fade.'>';
		if($title) echo '<h3 class="headline">'.htmlspecialchars_decode($title).'</h3><span class="line" style="margin-bottom:30px;"></span><div class="clearfix"></div>';
		if($wp_autop == 1){echo do_shortcode(htmlspecialchars_decode($text));}
		else{echo wpautop(do_shortcode(htmlspecialchars_decode($text)));}
		echo '</div>';
	}
	
}
