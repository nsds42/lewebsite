<?php
/* List Block */
if(!class_exists('ST_OurPlans_Block')) {
class ST_OurPlans_Block extends AQ_Block {

	function __construct() {
		$block_options = array(
		'name' => '<i class="fa fa-table"></i> Our Plans',
		'size' => 'col-md-12',
	);
	
	//create the widget
	parent::__construct('st_ourplans_block', $block_options);
	
	//add ajax functions
	add_action('wp_ajax_aq_block_ourplans_add_new', array($this, 'add_ourplans_item'));
	}
	
   function form($instance){
        $defaults = array(
            'title' => '', 		
			'column' =>'4',	
            'items' => array(
	            1 => array(
		            'title' => 'New Plans',
					'icon' => 'icon-laptop',
					'price' => '',
                    'content' => '',
                    'sign'=>'text button',
                    'sign1'=>'link button', 					 
                    'featured'=>'',
	            )
            ),           			
        );
        $instance = wp_parse_args($instance, $defaults);
        extract($instance);
		$column_option = array(
			'3' => '3 Column',
			'4' => '4 Column',   
			'5' => '5 Column'	
		); 
	?>
    <div class="description">
        <label for="<?php echo $this->get_field_id('title') ?>">
			Title <br/><em style="font-size: 0.8em;">(Please enter title)</em><br/>
			<?php echo aq_field_input('title', $block_id, $title, $size = 'full') ?>
        </label>
    </div>
    <div class="description cf">
	    <ul id="aq-sortable-list-<?php echo $block_id ?>" class="aq-sortable-list" rel="<?php echo $block_id ?>">
		    <?php
			    $items = is_array($items) ? $items : $defaults['items'];
			    $count = 1;
			    foreach($items as $item) {	
				    $this->item($item, $count);
				    $count++;
			    }
		    ?>
	    </ul>
	    <p></p>
	    	<a href="#" rel="ourplans" class="aq-sortable-add-new button">Add New</a>
	    <p></p>
    </div>
	<div class="cf"></div>
    <div class="description">
		<label for="<?php echo $this->get_field_id('column') ?>">
			Column <em style="font-size: 0.8em;">(Example: 4)</em><br/>
			<?php echo aq_field_select('column', $block_id, $column_option, $column, $block_id) ?>
		</label>
	</div>
<?php
}

function item($item = array(), $count = 0) {

?>
	<li id="sortable-item-<?php echo $count ?>" class="sortable-item" rel="<?php echo $count ?>">
		<div class="sortable-head cf">
			<div class="sortable-title">
				<strong><?php echo $item['title'] ?></strong>
			</div>
			<div class="sortable-handle">
				<a href="#">Open / Close</a>
			</div>
		</div>
	<div class="sortable-body">
	<div class="tab-desc description half">
		<label for="<?php echo $this->get_field_id('items') ?>-<?php echo $count ?>-title">
			Title<br/><em style="font-size: 0.8em;">(Please enter title plans)</em><br/>
	       <input type="text" id="<?php echo $this->get_field_id('items') ?>-<?php echo $count ?>-title" class="input-full" name="<?php echo $this->get_field_name('items') ?>[<?php echo $count ?>][title]" value="<?php echo $item['title'] ?>" />
		</label>
	</div>
	<div class="tab-desc description half last">
		<label for="<?php echo $this->get_field_id('items') ?>-<?php echo $count ?>-icon">
			Icon class name <br/><code>Ex: icon-cloud</code><a target="_blank" href="http://fortawesome.github.io/Font-Awesome/3.2.1/icons/"> view more icon </a><br/>
			<input type="text" id="<?php echo $this->get_field_id('items') ?>-<?php echo $count ?>-icon" class="input-full" name="<?php echo $this->get_field_name('items') ?>[<?php echo $count ?>][icon]" value="<?php echo $item['icon'] ?>" />
		</label>
	</div>
	<div class="cf"></div>
	<div class="tab-desc description half">
		<label for="<?php echo $this->get_field_id('items') ?>-<?php echo $count ?>-price">
			Price / month<br/><em style="font-size: 0.8em;">(Please enter price / month)</em><br/>
	       <textarea id="<?php echo $this->get_field_id('items') ?>-<?php echo $count ?>-price" class="textarea-full" name="<?php echo $this->get_field_name('items') ?>[<?php echo $count ?>][price]" rows="5"><?php echo $item['price'] ?></textarea>
		</label>
	</div>
	<div class="tab-desc description half last">
		<label for="<?php echo $this->get_field_id('items') ?>-<?php echo $count ?>-content">
			Content pricing<br/><em style="font-size: 0.8em;">(Please enter content Pricing)</em><br/>
			<textarea id="<?php echo $this->get_field_id('items') ?>-<?php echo $count ?>-content" class="textarea-full" name="<?php echo $this->get_field_name('items') ?>[<?php echo $count ?>][content]" rows="5"><?php echo $item['content'] ?></textarea>
		</label>
	</div>
	<div class="cf"></div>
	<div class="tab-desc description half">
		<label for="<?php echo $this->get_field_id('items') ?>-<?php echo $count ?>-sign">
			Order text<br/><em style="font-size: 0.8em;">(Please enter sign text)</em><br/>
	       <input type="text" id="<?php echo $this->get_field_id('items') ?>-<?php echo $count ?>-sign" class="input-full" name="<?php echo $this->get_field_name('items') ?>[<?php echo $count ?>][sign]" value="<?php echo $item['sign'] ?>" />
		</label>
	</div>
    <div class="tab-desc description half last">
		<label for="<?php echo $this->get_field_id('items') ?>-<?php echo $count ?>-sign1">
			Order link<br/><em style="font-size: 0.8em;">(Please enter sign link)</em><br/>
	       <input type="text" id="<?php echo $this->get_field_id('items') ?>-<?php echo $count ?>-sign1" class="input-full" name="<?php echo $this->get_field_name('items') ?>[<?php echo $count ?>][sign1]" value="<?php echo $item['sign1'] ?>" />
		</label>
	</div>   
	<div class="cf"></div>
    <div class="tab-desc description">
		<label for="<?php echo $this->get_field_id('items') ?>-<?php echo $count ?>-featured">
			Featured<br/><em style="font-size: 0.8em;">(Chosen featured enter class: premium)</em><br/>
	       <input type="text" id="<?php echo $this->get_field_id('items') ?>-<?php echo $count ?>-featured" class="input-full" name="<?php echo $this->get_field_name('items') ?>[<?php echo $count ?>][featured]" value="<?php echo $item['featured'] ?>" />
		</label>
	</div>
    <div class="cf"></div>
	<p class="tab-desc description"><a href="#" class="sortable-delete">Delete</a></p>
	</div>
	</li>

  <?php  
    }
    
    function block($instance){
    extract($instance);
    
    $title = (!empty($title) ? ''.esc_attr($title) : '');  
	?>
	
	<div class="container">
	
	<div class="sixteen columns">
		<h3 class="headline"><?php echo htmlspecialchars_decode($title); ?></h3><span class="line" style="margin-bottom:45px;"></span><div class="clearfix"></div>
	</div>
	
	<?php 
		if(!empty($items)){
		$i=0;
			foreach($items as $item){ 	
			$featured = (!empty($item['featured']) ? ''.esc_attr($item['featured']) : ''); 
			$i++;	
	?>
	<div class="<?php echo $featured; ?> plan <?php if($column== '3'){echo 'one-third column'; }elseif($column== '4'){echo 'four columns';}else{echo 'three columns';}?>">	
		<h3><i class="<?php echo esc_attr($item['icon']); ?>"></i> <?php echo htmlspecialchars_decode($item['title']); ?></h3>
		<div class="plan-price">
			<?php echo htmlspecialchars_decode($item['price']); ?>
		</div>
		<div class="plan-features">
			<ul>
				<?php echo htmlspecialchars_decode($item['content']); ?>
			</ul>
			<a class="button light" href="<?php echo esc_attr($item['sign1']); ?>"><?php echo htmlspecialchars_decode($item['sign']); ?></a>
		</div>
	</div>
	<?php 	
		}
	} ?>
</div>
	
	<?php 
	}
		/* AJAX add testimonial */
		function add_ourplans_item() {
		$nonce = $_POST['security'];	
		if (! wp_verify_nonce($nonce, 'aqpb-settings-page-nonce') ) die('-1');
		
		$count = isset($_POST['count']) ? absint($_POST['count']) : false;
		$this->block_id = isset($_POST['block_id']) ? $_POST['block_id'] : 'aq-block-9999';
		
		//default key/value for the testimonial
		$item = array(
            'title' => 'New Plans',
			'icon' => 'icon-laptop',
			'price' => '',
			'content' => '',
			'sign'=>'text button',
			'sign1'=>'link button', 					 
			'featured'=>'',
		);
		
		if($count) {
			$this->item($item, $count);
		} else {
			die(-1);
		}
		
		die();
		}
		
		function update($new_instance, $old_instance) {
			$new_instance = aq_recursive_sanitize($new_instance);
			return $new_instance;
		}
}
}