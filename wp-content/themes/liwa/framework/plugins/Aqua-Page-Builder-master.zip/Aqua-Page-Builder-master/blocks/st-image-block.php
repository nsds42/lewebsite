<?php
/* List Block */
if(!class_exists('ST_Image_Block')) {
class ST_Image_Block extends AQ_Block {

	function __construct() {
		$block_options = array(
		'name' => '<i class="fa fa-file-image-o"></i> Image',
		'size' => 'col-md-6',
	);

	//create the widget
	parent::__construct('st_image_block', $block_options);
	
	//add ajax functions
	
	}
   function form($instance){
        $defaults = array(
            'title' => '',
            'image'=>'',          
			'effect' => 'left_effect',	
			'layout' => 'full_layout'
        );
        $instance = wp_parse_args($instance, $defaults);
        extract($instance);  
		$layout_options = array(
			'full_layout' => '1/1 Column',
			'half_layout' => '1/2 Column',
			'one_third' => '1/3 Column',
			'two_third' => '2/3 Column',
			'one_fourth' => '1/4 Column',
			'three_fourth' => '3/4 Column',
		);    
		$effect_options = array(
			'left_effect' => 'fadeInLeft',
			'right_effect' => 'fadeInRight',
			'up_effect' => 'fadeInUp',					
		); 		
    ?>    
   	<div class="description">
		<label for="<?php echo $this->get_field_id('title') ?>">
			Title <br/><em style="font-size: 0.8em;">(Please enter title about)</em><br/>
			<?php echo aq_field_input('title', $block_id, $title, $size = 'full') ?>
		</label>
	</div>
	<div class="description">
		<label for="<?php echo $this->get_field_id('image') ?>">
			Image <br/><em style="font-size: 0.8em;">(Please Upload Image)</em><br/>
			<?php echo aq_field_upload('image', $block_id, $image, $media_type = 'image') ?>
		</label>
	</div>
	<div class="cf"></div>
	<div class="description half">
		<label for="<?php echo $this->get_field_id('layout') ?>">
			Chosen Layout<br/><em style="font-size: 0.8em;">(Default: Full width)</em><br/>
			<?php echo aq_field_select('layout', $block_id, $layout_options, $layout, $size = 'full') ?>
		</label>
	</div>
	<div class="description half last">
		<label for="<?php echo $this->get_field_id('effect') ?>">
			Chosen Effect<br/><em style="font-size: 0.8em;">(Default: fadeInLeft)</em><br/>
			<?php echo aq_field_select('effect', $block_id, $effect_options, $effect, $size = 'full') ?>
		</label>
	</div>
	<div class="cf"></div>
      <?php   
        }
   function block($instance){
   extract($instance);        
	$title = (!empty($title) ? ' '.esc_attr($title) : ''); 
	$desc = (!empty($desc) ? ' '.esc_attr($desc) : '');  
	
	$effect_fade = '';
	$columns_layout = '';
	switch($effect) {
			case 'right_effect':
				$effect_fade = 'data-appear-top-offset="-100" data-animated="fadeInRight"';
				break;
			case 'up_effect':
				$effect_fade = 'data-appear-top-offset="-100" data-animated="fadeInUp"';
				break;				
			default:
				$effect_fade = 'data-appear-top-offset="-100" data-animated="fadeInLeft"';	
		}
	switch($layout) {
			case 'half_layout':
				$columns_layout = 'eight columns';
				break;
			case 'one_third':
				$columns_layout = 'one-third column';
				break;
			case 'two_third':
				$columns_layout = 'two-thirds column';				
				break;
			case 'three_fourth':
				$columns_layout = 'twelve columns';
				break;
			case 'one_fourth':
				$columns_layout = 'four columns';
				break;	
			default:
				$columns_layout = 'sixteen columns';	
		}
    ?>
		<!-- Image? -->
		<div class="<?php echo $columns_layout; ?>" <?php echo $effect_fade; ?>>
			<img src="<?php echo esc_url($image); ?>">
		</div>
	<?php 
}
function update($new_instance, $old_instance) {
		$new_instance = aq_recursive_sanitize($new_instance);
		return $new_instance;
	}
}
}