<?php
/* List Block */
if(!class_exists('ST_What_We_Do_Block')) {
class ST_What_We_Do_Block extends AQ_Block {

	function __construct() {
		$block_options = array(
		'name' => '<i class="fa fa-cogs"></i> What We Do',
		'size' => 'col-md-12',
	);
	
	//create the widget
	parent::__construct('st_what_we_do_block', $block_options);
	
	//add ajax functions
	add_action('wp_ajax_aq_block_whatwedo_add_new', array($this, 'add_whatwedo_item'));
	
	}
	
   function form($instance){
        $defaults = array(
            'title' => '', 
			'id' => 'services1',
            'image' => '',         
            'items' => array(
	            1 => array(
		            'title' => 'New Title Service',
		            'content' => '',
					'photo' => ''
	            )
            ),
        );
        $instance = wp_parse_args($instance, $defaults);
        extract($instance);
	?>   
    <div class="description">
        <label for="<?php echo $this->get_field_id('title') ?>">
        Title <br/><em style="font-size: 0.8em;">(Please enter title our services)</em><br/>
        <?php echo aq_field_input('title', $block_id, $title, $size = 'full') ?>
        </label>
    </div>
	<div class="cf"></div>

    <div class="description cf">
	    <ul id="aq-sortable-list-<?php echo $block_id ?>" class="aq-sortable-list" rel="<?php echo $block_id ?>">
		    <?php
			    $items = is_array($items) ? $items : $defaults['items'];
			    $count = 1;
			    foreach($items as $item) {	
				    $this->item($item, $count);
				    $count++;
			    }
		    ?>
	    </ul>
	    <p></p>
	    	<a href="#" rel="whatwedo" class="aq-sortable-add-new button">Add New</a>
	    <p></p>
    </div>
    <div class="cf"></div>
	<div class="description">
		<label for="<?php echo $this->get_field_id('id') ?>">
			ID For Block <br/><em style="font-size: 0.8em;">(Please enter id Block -> Scroll To Menu.)</em><br/>
			<?php echo aq_field_input('id', $block_id, $id, $size = 'full') ?>
		</label>
	</div>
<?php
}

function item($item = array(), $count = 0) {

?>
	<li id="sortable-item-<?php echo $count ?>" class="sortable-item" rel="<?php echo $count ?>">
		<div class="sortable-head cf">
			<div class="sortable-title">
				<strong><?php echo $item['title'] ?></strong>
			</div>
			<div class="sortable-handle">
				<a href="#">Open / Close</a>
			</div>
		</div>
	<div class="sortable-body">
	<div class="tab-desc description">
		<label for="<?php echo $this->get_field_id('items') ?>-<?php echo $count ?>-title">
			Title<br/><em style="font-size: 0.8em;">(Please enter title)</em><br/>
	<input type="text" id="<?php echo $this->get_field_id('items') ?>-<?php echo $count ?>-title" class="input-full" name="<?php echo $this->get_field_name('items') ?>[<?php echo $count ?>][title]" value="<?php echo $item['title'] ?>" />
		</label>
	</div>
    <div class="cf"></div>
	<div class="tab-desc description">
		<label for="<?php echo $this->get_field_id('items') ?>-<?php echo $count ?>-content">
			Content<br/><em style="font-size: 0.8em;">(Please enter content)</em><br/>
			<textarea id="<?php echo $this->get_field_id('items') ?>-<?php echo $count ?>-content" class="textarea-full" name="<?php echo $this->get_field_name('items') ?>[<?php echo $count ?>][content]" rows="5"><?php echo $item['content'] ?></textarea>
		</label>
	</div>
	<div class="tab-desc description">
		<label for="<?php echo $this->get_field_id('items') ?>-<?php echo $count ?>-photo">
			Photo <em style="font-size: 0.8em;">(Recommended size: 150 x 130 pixel)</em><br/>
			<input type="text" id="<?php echo $this->get_field_id('items') ?>-<?php echo $count ?>-photo" class="input-full input-upload" value="<?php echo $item['photo'] ?>" name="<?php echo $this->get_field_name('items') ?>[<?php echo $count ?>][photo]">
			<a href="#" class="aq_upload_button button" rel="image">Upload</a><p></p>
		</label>
	</div>
	<p class="tab-desc description"><a href="#" class="sortable-delete">Delete</a></p>
	</div>
	</li>

  <?php  
    }
	
    function block($instance){
    extract($instance);    
	?>	
	
    <section id="<?php echo esc_attr($id); ?>">
		<!--What we do-->
		<div class="whatWeDo">
		<?php if($title != ''){ ?>
			<!--Container-->
			<div class="container clearfix">
				<div class="bigTitle "><h1 class="tCenter"><?php echo esc_attr($title); ?></h1></div>	
			</div>
			<!--End container-->
		<?php } ?>	
			<!--What we do content-->
			<div class="wwdContent">
				<!--Container-->
				<div class="container clearfix">		
					<!--What we do inner-->
					<div class="wwdInner clearfix ofsInTop">
						<?php if(!empty($items)){
							$i=0;
							foreach($items as $item){ $i++;
								if($item['content'] != ''){ ?>
						<?php if (($i % 3) == 1){echo '<div class="servicesContent clearfix">'; }else {}?>	
						
						<div class="one-third column expertise tCenter">
							<div class="expImg">
							<img src="<?php echo esc_url($item['photo']); ?>" alt="">
							</div>
							<h2><?php echo htmlspecialchars_decode($item['title']); ?></h2>
							<p><?php echo htmlspecialchars_decode($item['content']); ?></p>
						</div>
						
						<?php if (($i % 3) == 0){echo '</div>'; }else {}?>
						
						<?php 
									}
								}
							}
						?>	
					</div>	
					<!--End what we do inner-->
				</div>
				<!--End container-->
			</div>
			<!--What we do content-->
		</div>
		<!--End what we do-->	
	</section>
  
  
    <?php }
		/* AJAX add testimonial */
		function add_whatwedo_item() {
		$nonce = $_POST['security'];	
		if (! wp_verify_nonce($nonce, 'aqpb-settings-page-nonce') ) die('-1');
		
		$count = isset($_POST['count']) ? absint($_POST['count']) : false;
		$this->block_id = isset($_POST['block_id']) ? $_POST['block_id'] : 'aq-block-9999';
		
		//default key/value for the testimonial
		$item = array(
			'title' => 'New Title Service',
            'content' => '',
			'photo' => ''
		);
		
		if($count) {
			$this->item($item, $count);
		} else {
			die(-1);
		}
		
		die();
		}
		
		function update($new_instance, $old_instance) {
			$new_instance = aq_recursive_sanitize($new_instance);
			return $new_instance;
		}
}
}