<?php 
class ST_Ourprocess_Block extends AQ_Block{
    function __construct(){
        $block_option=array(
            'name' => '<i class="fa fa-indent"></i> OurProcess',
            'size' => 'col-md-12',
        );
        parent::__construct('st_ourprocess_block', $block_option);
        add_action('wp_ajax_aq_block_ourprocess_add_new', array($this, 'add_ourprocess_item'));
    }
    function form($instance){
        $defaults =array(
        'title' => '', 
		'id' => 'ourprocess',
        'items'=> array(
            1=>array(
	            'title' => 'New Process',
                'desc'=>'',
	            'content' => '',
	            'icon'  => 'lamp',
            )
        ),
		'column' => '3'
        );        
        $instance=wp_parse_args($instance,$defaults);
        extract($instance);
		
		$column_options = array(
			'2' => '2 Columm',
			'3' => '3 Columm',
			'4' => '4 Columm',
		);
		
    ?>    
   <h3 style="text-align: center;">Our Process</h3>
  	<div class="description half">
		<label for="<?php echo $this->get_field_id('title') ?>">
			Title <br/><em style="font-size: 0.8em;">(Please enter title Our Process)</em><br/>
			<?php echo aq_field_input('title', $block_id, $title, $size = 'full') ?>
		</label>
	</div>
	<div class="description half last">
		<label for="<?php echo $this->get_field_id('column') ?>">
			Chosen column<br/><em style="font-size: 0.8em;">(Default: 3 column)</em><br/>
			<?php echo aq_field_select('column', $block_id, $column_options, $column, $size = 'full') ?>
		</label>
	</div>
    
    <div class="cf"></div>
    
    <div class="description cf">
	    <ul id="aq-sortable-list-<?php echo $block_id ?>" class="aq-sortable-list" rel="<?php echo $block_id ?>">
		    <?php
			    $items = is_array($items) ? $items : $defaults['items'];
			    $count = 1;
			    foreach($items as $item) {	
				    $this->item($item, $count);
				    $count++;
			    }
		    ?>
	    </ul>
	    <p></p>
	    	<a href="#" rel="ourprocess" class="aq-sortable-add-new button">Add New</a>
	    <p></p>
    </div>
	<div class="cf"></div>
	<div class="description">
		<label for="<?php echo $this->get_field_id('id') ?>">
			ID For Block <br/><em style="font-size: 0.8em;">(Please enter id Block -> Scroll To Menu.)</em><br/>
			<?php echo aq_field_input('id', $block_id, $id, $size = 'full') ?>
		</label>
	</div>
    
    <?php }
    
    function item($item = array(), $count = 0) {

    ?>
    <li id="sortable-item-<?php echo $count ?>" class="sortable-item" rel="<?php echo $count ?>">
	    <div class="sortable-head cf">
		    <div class="sortable-title">
		    	<strong><?php echo $item['title'] ?></strong>
		    </div>
		    <div class="sortable-handle">
		    	<a href="#">Open / Close</a>
		    </div>
	    </div>
	    <div class="sortable-body">
		    <div class="tab-desc description half">
			    <label for="<?php echo $this->get_field_id('items') ?>-<?php echo $count ?>-title">
				    Name Process<br/>
				    <input type="text" id="<?php echo $this->get_field_id('items') ?>-<?php echo $count ?>-title" class="input-full" name="<?php echo $this->get_field_name('items') ?>[<?php echo $count ?>][title]" value="<?php echo $item['title'] ?>" />
			    </label>
		    </div>
            <div class="tab-desc description half last">
		        <label for="<?php echo $this->get_field_id('items') ?>-<?php echo $count ?>-icon">
		            Icon class name <code>Ex: globe</code><a target="_blank" href="http://fontello.com/"> view more icon </a><br/>
		            <input type="text" id="<?php echo $this->get_field_id('items') ?>-<?php echo $count ?>-icon" class="input-full" name="<?php echo $this->get_field_name('items') ?>[<?php echo $count ?>][icon]" value="<?php echo $item['icon'] ?>" />
		        </label>
		    </div>
             <div class="cf"></div>
             <div class="tab-desc description">
			    <label for="<?php echo $this->get_field_id('items') ?>-<?php echo $count ?>-desc">
				    Desc Process<br/>
				    <textarea id="<?php echo $this->get_field_id('items') ?>-<?php echo $count ?>-desc" class="textarea-full" name="<?php echo $this->get_field_name('items') ?>[<?php echo $count ?>][desc]" rows="5"><?php echo $item['desc'] ?></textarea>
			    </label>
		    </div>
		    <div class="tab-desc description">
			    <label for="<?php echo $this->get_field_id('items') ?>-<?php echo $count ?>-content">
				    Content Process<br/>
				    <textarea id="<?php echo $this->get_field_id('items') ?>-<?php echo $count ?>-content" class="textarea-full" name="<?php echo $this->get_field_name('items') ?>[<?php echo $count ?>][content]" rows="5"><?php echo $item['content'] ?></textarea>
			    </label>
		    </div>
		    
	    <p class="tab-desc description"><a href="#" class="sortable-delete">Delete</a></p>
	    </div>
    </li>
    <?php
    }
    
    function block($instance){
        extract($instance);
    $title = (!empty($title) ? ' '.esc_attr($title) : ''); 
    $column = (!empty($column) ? ' '.esc_attr($column) : '');
    ?>
    <section id="<?php echo esc_attr($id); ?>">
    <div class="process tCenter ofsInTop ofsInBottom ofsBottom">
    			<!--Container-->
    			<div class="container clearfix">				
    	<h2 class="title"><?php echo htmlspecialchars_decode($title);?></h2>					
    	<!--Process holder-->
    	<div class="processHolder clearfix ofsTop">
    <?php 
            if(!empty($items)){
                foreach($items as $item){
                    ?>
                    <div class="one-third column prSingle" style="width: <?php 
					if($column=='2'){echo '460px';}
					elseif($column=='3'){echo '300px';}
					elseif($column=='4'){echo '220px';}
					?>!important;">
						<div class="prIcoHolder"><div class="prIco"><i class="icon-<?php echo $item['icon']?> innerIco"></i></div></div>
						<h1 class="prTitle"><?php echo htmlspecialchars_decode($item['title'])?></h1>
						<p><?php echo htmlspecialchars_decode($item['desc'])?></p>
						
						<ul>
							<?php echo htmlspecialchars_decode($item['content'])?>
					   </ul>
					</div>
				<?php
              }
         }
	?>
    				</div>
				<!--End process holder-->				
					</div>
					<!--End container-->				
				</div>
				<!--End process-->
               </section>	
  
	<?php
	}
    function add_ourprocess_item() {
    $nonce = $_POST['security'];	
    if (! wp_verify_nonce($nonce, 'aqpb-settings-page-nonce') ) die('-1');
    
    $count = isset($_POST['count']) ? absint($_POST['count']) : false;
    $this->block_id = isset($_POST['block_id']) ? $_POST['block_id'] : 'aq-block-9999';
    
    //default key/value for the testimonial
    $item = array(
	    'title' => 'New Process',
        'desc'=>'',
        'content' => '',
        'icon'  => 'lamp',
    );
    
    if($count) {
    	$this->item($item, $count);
    } else {
    	die(-1);
    }
    
    die();
    }
    function update($new_instance, $old_instance) {
		$new_instance = aq_recursive_sanitize($new_instance);
		return $new_instance;
	}
}
