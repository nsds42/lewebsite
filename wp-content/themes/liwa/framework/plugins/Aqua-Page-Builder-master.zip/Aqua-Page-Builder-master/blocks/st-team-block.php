<?php
/* Work Block */
if(!class_exists('ST_Team_Block')) {
class ST_Team_Block extends AQ_Block {
   
   function __construct() {
	    $block_options = array(
	    'name' => '<i class="fa fa-user"></i> Our Team',
	    'size' => 'col-md-12',
    );
    
	    //create the widget
	    parent::__construct('st_team_block', $block_options);
    } 
    
   function form($instance){
        $defaults = array(
			'title' => 'Title Our Team',
			'show' => '99',
			'orderby' => 'date',
			'orderpost' => 'ASC',
			'class' => ''	
        );
        $instance = wp_parse_args($instance, $defaults);
        extract($instance);
		$orderpost_options = array (
			'ASC' => 'ASC : lowest to highest',
			'DESC' => 'DESC : highest to lowest',	
		);
		
		$orderby_options = array (
			'title' => 'Title',
			'date' => 'Date',
			'rand' => 'Random'
		);
        ?>
		<div class="description">
	        <label for="<?php echo $this->get_field_id('title') ?>">
	        Title<br/><em style="font-size: 0.8em;">(Please enter title team)</em><br/>
	        <?php echo aq_field_input('title', $block_id, $title, $size = 'full') ?>
	        </label>
	    </div>	
		<div class="cf"></div>
    	<div class="description third">
    		<label for="<?php echo $this->get_field_id('show') ?>">
    			Show Team<br/><em style="font-size: 0.8em;">(Chosen number team. Ex: 6)</em><br/>
    			<?php echo aq_field_input('show', $block_id, $show, $size = 'full',$type = 'number') ?>
    		</label>
    	</div>
		<div class="description third">
    		<label for="<?php echo $this->get_field_id('orderpost') ?>">
    			Sort Order<br/><em style="font-size: 0.8em;">Sort from lowest to highest (Default)</em><br/>
    			<?php echo aq_field_select('orderpost', $block_id, $orderpost_options, $orderpost, $size = 'full') ?>
    		</label>
    	</div>
		<div class="description third last">
    		<label for="<?php echo $this->get_field_id('orderby') ?>">
    			Order by<br/><em style="font-size: 0.8em;">Title (Default)</em><br/>
    			<?php echo aq_field_select('orderby', $block_id, $orderby_options, $orderby, $size = 'full') ?>
    		</label>
    	</div>
		<div class="cf"></div>
		<div class="description">
	        <label for="<?php echo $this->get_field_id('class') ?>">
	        Class<br/><em style="font-size: 0.8em;">(Please enter class)</em><br/>
	        <?php echo aq_field_input('class', $block_id, $class, $size = 'full') ?>
	        </label>
	    </div>	
        <?php
        } 
   function block($instance){
    extract($instance);
		$title1 = (!empty($title) ? ' '.esc_attr($title) : '');  
		$desc1 = (!empty($subtitle) ? ' '.esc_attr($subtitle) : '');  
		$show1 = (!empty($show) ? ' '.esc_attr($show) : '');
		$text1 = (!empty($text) ? ' '.esc_attr($text) : '');
	?>
	
	<div class="container">

	<!-- ShowBiz Carousel -->
	<div id="team" class="showbiz-container sixteen columns <?php echo $class; ?>">
	
	<!-- Headline -->
	<h3 class="headline"><?php echo htmlspecialchars_decode($title1); ?></h3>
	<span class="line" style="margin-bottom:0;"></span>
		
	<!-- Navigation -->
	<div class="showbiz-navigation">
		<div id="showbiz_left_4" class="sb-navigation-left"><i class="icon-angle-left"></i></div>
		<div id="showbiz_right_4" class="sb-navigation-right"><i class="icon-angle-right"></i></div>
	</div>
	<div class="clearfix"></div>

	<!-- Entries -->
	<div class="showbiz" data-left="#showbiz_left_4" data-right="#showbiz_right_4">
		<div class="overflowholder">

			<ul data-appear-top-offset="-100" data-animated="fadeInUp">
			<?php 
						$args = array(   
							'post_type' => 'team',   
							'posts_per_page' => $show1,
							'order' => $orderpost,
							'orderby' => $orderby, 							
						);  
						$wp_query = new WP_Query($args);					
						while ($wp_query -> have_posts()) : $wp_query -> the_post(); 
						$twitter = get_post_meta(get_the_ID(),'_cmb_twitter', true);
						$facebook = get_post_meta(get_the_ID(),'_cmb_facebook', true);
						$linkedin = get_post_meta(get_the_ID(),'_cmb_linkedin', true);
						$googleplus = get_post_meta(get_the_ID(),'_cmb_googleplus', true);
						$dribbble = get_post_meta(get_the_ID(),'_cmb_dribbble', true);
						$forrst = get_post_meta(get_the_ID(),'_cmb_forrst', true);
						$instagram	= get_post_meta(get_the_ID(),'_cmb_instagram', true);
						$tumblr	 = get_post_meta(get_the_ID(),'_cmb_tumblr', true);
						$github = get_post_meta(get_the_ID(),'_cmb_github', true);
						$pinterest = get_post_meta(get_the_ID(),'_cmb_pinterest', true);
						$team_job = get_post_meta(get_the_ID(),'_cmb_team_job', true);
					?>		
					<li>
						<?php $params = array( 'width' => 488, 'height' => 365 );
							  $image = bfi_thumb( wp_get_attachment_url(get_post_thumbnail_id()), $params ); ?>
						<img class="mediaholder team-img" src="<?php echo $image; ?>" alt="<?php the_title(); ?>"/>				
						<ol class="social-icons">
							<?php if($twitter !=''){?>
								<li><a href="<?php echo $twitter;?>" class="twitter"><i class="icon-twitter"></i></a></li>
							<?php }?>
							<?php if($facebook !=''){?>	
								<li><a href="<?php echo $facebook;?>" class="facebook"><i class="icon-facebook"></i></a></li>
							<?php }?>
							<?php if($linkedin !=''){?>	
								<li><a href="<?php echo $linkedin;?>" class="linkedin"><i class="icon-linkedin"></i></a></li>
							<?php }?>
							<?php if($googleplus !=''){?>	
								<li><a href="<?php echo $googleplus;?>" class="gplus"><i class="icon-gplus"></i></a></li>
							<?php }?>
							<?php if($dribbble !=''){?>	
								<li><a href="<?php echo $dribbble;?>" class="dribbble"><i class="icon-dribbble"></i></a></li>
							<?php }?>	
							<?php if($forrst !=''){?>
								<li><a href="<?php echo $forrst;?>" class="forrst"><i class="icon-forrst"></i></a></li>
							<?php }?>	
							<?php if($instagram !=''){?>
								<li><a href="<?php echo $instagram;?>" class="instagram"><i class="icon-instagram"></i></a></li>
							<?php }?>
							<?php if($tumblr !=''){?>	
								<li><a href="<?php echo $tumblr;?>" class="tumblr"><i class="icon-tumblr"></i></a></li>
							<?php }?>	
							<?php if($github !=''){?>
								<li><a href="<?php echo $github;?>" class="github"><i class="icon-github"></i></a></li>
							<?php }?>	
							<?php if($pinterest !=''){?>
								<li><a href="<?php echo $pinterest;?>" class="pinterest"><i class="icon-pinterest"></i></a></li>
							<?php }?>	
						</ol>  
						
						<div class="team-name"><a href="<?php the_permalink(); ?>"><h5><?php the_title();?></h5></a> <span><?php echo $team_job; ?></span></div>
						<div class="team-about"><?php the_excerpt(); ?></div>
						<div class="clearfix"></div>
					</li>	
				<?php endwhile; ?>
			</ul>
			<div class="clearfix"></div>
		</div>
		<div class="clearfix"></div>
	</div>
	</div>
</div>

    <?
    }
    function update($new_instance, $old_instance) {
	    $new_instance = aq_recursive_sanitize($new_instance);
	    return $new_instance;
	}      
}
}