<?php 
class ST_Faq_Block extends AQ_Block{
    function __construct(){
        $block_option=array(
            'name' => '<i class="fa fa-question"></i> FAQ',
            'size' => 'col-md-12',
        );
        parent::__construct('st_faq_block', $block_option);
        add_action('wp_ajax_aq_block_faq_add_new', array($this, 'add_faq_item'));
    }
	
    function form($instance){
        $defaults =array(
	        'title' => 'Title',	
			'effect' => 'left_effect',	
			'layout' => 'full_layout',	
	        'items'=> array(
	            1=>array(
		            'title' => 'Frequently Asked Question',
		            'content' => '',
					'icon' => '',
	            )
	        ),
        );        
		
        $instance=wp_parse_args($instance,$defaults);
        extract($instance);
		$layout_options = array(
			'full_layout' => '1/1 Column',
			'half_layout' => '1/2 Column',
			'one_third' => '1/3 Column',
			'two_third' => '2/3 Column',
			'one_fourth' => '1/4 Column',
			'three_fourth' => '3/4 Column',
		);    
		$effect_options = array(
			'left_effect' => 'fadeInLeft',
			'right_effect' => 'fadeInRight',
			'up_effect' => 'fadeInUp',					
		); 
    ?>    
    <div class="descriptions">
        <label for="<?php echo $this->get_field_id('title') ?>">
	    	Title:
	    	<?php echo aq_field_input('title', $block_id, $title, $size = 'full') ?>
	    </label>
    </div>    
    <div class="description cf">
	    <ul id="aq-sortable-list-<?php echo $block_id ?>" class="aq-sortable-list" rel="<?php echo $block_id ?>">
		    <?php
			    $items = is_array($items) ? $items : $defaults['items'];
			    $count = 1;
			    foreach($items as $item) {	
				    $this->item($item, $count);
				    $count++;
		    	}
		    ?>
	    </ul>
	    <p></p>
	    	<a href="#" rel="faq" class="aq-sortable-add-new button">Add New</a>
	    <p></p>
    </div>
	<div class="cf"></div>
	<div class="description half">
		<label for="<?php echo $this->get_field_id('layout') ?>">
			Chosen Layout<br/><em style="font-size: 0.8em;">(Default: Full width)</em><br/>
			<?php echo aq_field_select('layout', $block_id, $layout_options, $layout, $size = 'full') ?>
		</label>
	</div>
	<div class="description half last">
		<label for="<?php echo $this->get_field_id('effect') ?>">
			Chosen Effect<br/><em style="font-size: 0.8em;">(Default: fadeInLeft)</em><br/>
			<?php echo aq_field_select('effect', $block_id, $effect_options, $effect, $size = 'full') ?>
		</label>
	</div>
	<div class="cf"></div>
    <?php }
    function item($item = array(), $count = 0) {

    ?>
    <li id="sortable-item-<?php echo $count ?>" class="sortable-item" rel="<?php echo $count ?>">
	    <div class="sortable-head cf">
		    <div class="sortable-title">
		    	<strong><?php echo $item['title'] ?></strong>
		    </div>
		    <div class="sortable-handle">
		    	<a href="#">Open / Close</a>
		    </div>
	    </div>	
	
	    <div class="sortable-body">
		    <div class="tab-desc description">
			    <label for="<?php echo $this->get_field_id('items') ?>-<?php echo $count ?>-title">
			    	Enter Title<br/>
			    	<input type="text" id="<?php echo $this->get_field_id('items') ?>-<?php echo $count ?>-title" class="input-full" name="<?php echo $this->get_field_name('items') ?>[<?php echo $count ?>][title]" value="<?php echo $item['title'] ?>" />
		    	</label>
		    </div>
			
		    <div class="tab-desc description">
		        <label for="<?php echo $this->get_field_id('items') ?>-<?php echo $count ?>-icon">
		            Icon class name <br/><code>Ex: icon-cloud</code><a target="_blank" href="http://fortawesome.github.io/Font-Awesome/3.2.1/icons/"> view more icon </a><br/>
		            <input type="text" id="<?php echo $this->get_field_id('items') ?>-<?php echo $count ?>-icon" class="input-full" name="<?php echo $this->get_field_name('items') ?>[<?php echo $count ?>][icon]" value="<?php echo $item['icon'] ?>" />
		        </label>
		    </div>
			<div class="tab-desc description">
		        <label for="<?php echo $this->get_field_id('items') ?>-<?php echo $count ?>-content">
					Content<br/><em style="font-size: 0.8em;">(Please enter content)</em><br/>
					<textarea id="<?php echo $this->get_field_id('items') ?>-<?php echo $count ?>-content" class="textarea-full" name="<?php echo $this->get_field_name('items') ?>[<?php echo $count ?>][content]" rows="5"><?php echo $item['content'] ?></textarea>
				</label>
		    </div>
	    <p class="tab-desc description"><a href="#" class="sortable-delete">Delete</a></p>
	    </div>
	</li>
    <?php
    }
    
    function block($instance){
        extract($instance);
		
    $effect_fade = '';
	$columns_layout = '';
	switch($effect) {
			case 'right_effect':
				$effect_fade = 'data-appear-top-offset="-100" data-animated="fadeInRight"';
				break;
			case 'up_effect':
				$effect_fade = 'data-appear-top-offset="-100" data-animated="fadeInUp"';
				break;				
			default:
				$effect_fade = 'data-appear-top-offset="-100" data-animated="fadeInLeft"';	
		}
	switch($layout) {
			case 'half_layout':
				$columns_layout = 'eight columns';
				break;
			case 'one_third':
				$columns_layout = 'one-third column';
				break;
			case 'two_third':
				$columns_layout = 'two-thirds column';				
				break;
			case 'three_fourth':
				$columns_layout = 'twelve columns';
				break;
			case 'one_fourth':
				$columns_layout = 'four columns';
				break;	
			default:
				$columns_layout = 'sixteen columns';	
		}
    ?>
	<div class="alt <?php echo $columns_layout; ?>" <?php echo $effect_fade; ?>>
		<?php if(!empty($items)){
			$i=0;
                foreach($items as $item){ $i++;
                    if($item['content'] != ''){
            ?>
		<!-- Toggle 1 -->
		<div class="toggle-wrap faq">
			<span class="trigger <?php if($i==1){echo 'opened';}?>"><a href="#"><i class="<?php echo esc_attr($item['icon']); ?>"></i> <?php echo htmlspecialchars_decode($item['title']);?></a></span>
			<div class="toggle-container">
				<?php echo wpautop(do_shortcode(htmlspecialchars_decode($item['content'])));?>
			</div>
		</div>
		 <?php 
                }
            }
        } ?>
	</div>
	
	<?php
	
	}
    function add_faq_item() {
	    $nonce = $_POST['security'];	
	    if (! wp_verify_nonce($nonce, 'aqpb-settings-page-nonce') ) die('-1');
	    
	    $count = isset($_POST['count']) ? absint($_POST['count']) : false;
	    $this->block_id = isset($_POST['block_id']) ? $_POST['block_id'] : 'aq-block-9999';
	    
	    //default key/value for the testimonial
	    $item = array(
		    'title' => 'Frequently Asked Question',
		    'content' => '',
			'icon' => '',
	    );
	    
	    if($count) {
	   		$this->item($item, $count);
	    } else {
	    	die(-1);
	    }
	    
	    die();
    }
    function update($new_instance, $old_instance) {
		$new_instance = aq_recursive_sanitize($new_instance);
		return $new_instance;
	}
}
